var galleryTop = new Swiper('.gallery-top', {
    spaceBetween: 10,
    pagination: {
        el: ".swiper-pagination",
        type: "fraction",
    },
});